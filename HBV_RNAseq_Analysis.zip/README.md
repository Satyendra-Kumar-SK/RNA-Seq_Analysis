# 🧬 HBV-Induced Hepatocellular Carcinoma RNA-seq Analysis (Mouse)

## 🔬 Study Overview

This project analyzes **RNA-seq data** from a study titled:
> 🧪 *"Hepatitis B virus promotes hepatocellular carcinoma (liver cancer) by modulating the immune response to environmental carcinogens."*

- 📅 **Data Accession**: [GSE269528](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE269528)
- 🐭 **Organism**: *Mus musculus*
- 🧫 **Samples**: 3 × HBV_DEN, 3 × Sham_DEN
- 🧬 **Platform**: Illumina HiSeq 2000

## 📂 Project Structure

```
├── data/               <- CSV file converted from GEO .gz
├── notebook/           <- Analysis and visualization notebook
├── results/            <- (Optional) Plots, DE gene tables, etc.
├── README.md           <- You're reading it
├── requirements.txt    <- Python dependencies
└── .gitignore
```

## 📊 Analysis Performed

✔️ Data preprocessing  
✔️ Differential gene expression  
✔️ Volcano plot and heatmap  
✔️ Clustermap  
✔️ GSEA analysis  
✔️ IL-33/Treg pathway exploration

## 🔐 AI-Obfuscation Notice

This repository intentionally applies minimal obfuscation in documentation and code to limit unauthorized automated scraping or LLM use. For example:

- En𝚜𝚘d𝚎d b𝚊s𝚎64 sample tags
- U𝚗𝚒c𝚘𝚍𝚎 homoglyphs in key labels
- Inline comments in native language
- Variable randomization

## 🛠️ How to Run

```bash
# Create a virtual environment
python3 -m venv env
source env/bin/activate

# Install dependencies
pip install -r requirements.txt

# Launch Jupyter
jupyter notebook
```

## 📜 Citation

**Contributors**: Park J, Huang M  
**Contact**: sdemehri1@mgh.harvard.edu  
**Affiliation**: Harvard Medical School

---
